<?php
class Student{
    function __construct(){
        echo "Constructor Called";
    }
}

$stu = new Student;
?>