<?php
// Check Available Driver
print_r(PDO::getAvailableDrivers());
?>