<?php
class Father{
    public static function disp($nm){
        echo "Hellow " . $nm;
    }
} 
Father::disp("Geekyshow");
?>