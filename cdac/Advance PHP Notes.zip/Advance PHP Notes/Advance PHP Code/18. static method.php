<?php
class Father{
    public static function disp(){
        echo "Hellow Geekyshows";
    }
} 
Father::disp(); // accessing static method without object
?>