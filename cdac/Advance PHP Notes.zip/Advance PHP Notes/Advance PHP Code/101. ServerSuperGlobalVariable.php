<?php
 echo "Server Name: " . $_SERVER['SERVER_NAME'] . "<br>";
 echo "Server IP: " . $_SERVER['SERVER_ADDR'] . "<br>";
 echo "Server Software: " . $_SERVER['SERVER_SOFTWARE'] . "<br>";
 echo "Request Method: " . $_SERVER['REQUEST_METHOD'] . "<br>";
 echo "Request Time: " . $_SERVER['REQUEST_TIME'] . "<br>";
 echo "Document Root: " . $_SERVER['DOCUMENT_ROOT'] . "<br>";
 echo "HTTP HOST: " . $_SERVER['HTTP_HOST'] . "<br>";
 echo "HTTP User Agent: " . $_SERVER['HTTP_USER_AGENT'] . "<br>";
 echo "Remote IP: " . $_SERVER['REMOTE_ADDR'] . "<br>";
 echo "PHP SELF: " . $_SERVER['PHP_SELF'] . "<br>";


 // http://php.net/manual/en/reserved.variables.server.php
?>