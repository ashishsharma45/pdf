<?php
	$name1 = "Geeky ";
	$name2 = "Shows ";
	$name3 = "Good ";
	$name3 .= "Site "; // $name3 = $name3 . "Site"
	echo $name1 . $name2 . "<br />";
	echo $name3;
	
?>