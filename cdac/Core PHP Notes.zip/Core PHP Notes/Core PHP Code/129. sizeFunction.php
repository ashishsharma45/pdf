<?php
		echo filesize("geek.txt");
?>