<?php
	// $name = array("Rahul", "Sonam", "Sumit", "Priti");
	$name[0] = "Rahul";
	$name[1] = "Sonam";
	$name[2] = "Sumit";
	$name[3] = "Priti";
	for($i=0; $i<=3; $i++)	// for($i=0; $i<count($name); $i++)
	{
		// echo $name[$i], "<br />";
		echo "\$name[$i] = ",$name[$i], "<br />";
	}
?>