<?php
		printf("%d <br />", -45);	// print -45
		printf("%d <br />", +45);	// not print +45
		printf("%d <br />", 45);	// not print +45
		printf("%+d <br />", 45);	// print +45
?>