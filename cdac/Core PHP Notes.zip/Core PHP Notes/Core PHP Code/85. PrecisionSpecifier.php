<?php
		printf("%d <br />", 45);		// 45
		printf("%f <br />", 45);		// 45.000000
		printf("%.2f <br />", 45);		// 45.00
		printf("%08f <br />", 45);		// 00000045
		printf("%08.2f <br />", 45);	// 00045.00
		printf("%s <br />", "Geeky");	// Geeky
		printf("%.2s <br />", "Geeky");	// Ge
		printf("%'08.2s <br />", "Geeky");	// ******Ge
		
?>