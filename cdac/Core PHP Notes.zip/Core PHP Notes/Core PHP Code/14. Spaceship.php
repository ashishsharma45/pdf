<?php
	$num1 = "b";
	$num2 = "a";
	echo $num1 <=> $num2;
?>