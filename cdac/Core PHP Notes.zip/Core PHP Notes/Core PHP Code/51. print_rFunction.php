<?php
	// $name = array("Rahul", "Sonam", "Sumit", "Priti");
	$name [0] = "Rahul";
	$name [1] = "Sonam";
	$name [2] = "Sumit";
	$name [3] = "Priti";
	
	print_r ($name);	// It will print information
	
	//$results = print_r($name, true);  // When Return is set to TRUE, 
									 // print_r( ) will 
									// return the information 
								   //rather than print it.
	
?>