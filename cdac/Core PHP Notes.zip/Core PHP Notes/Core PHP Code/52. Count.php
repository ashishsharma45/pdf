<?php
	$name [0] = "Rahul";
	$name [1] = "Sonam";
	$name [2] = "Sumit";
	$name [3] = "Priti";
	echo count($name);
	
?>