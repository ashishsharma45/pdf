<?php
	$num = 1;
	do
	{
		echo "GeekyShows Count: $num <br />";
		$num++;
	} while ($num <= 3);
?>