<?php
		if (copy("geek.txt", "shows1.txt"))
		{
			echo "File Copied";
		}
		else 
		{
			echo "Not Copied!";
		}
?>