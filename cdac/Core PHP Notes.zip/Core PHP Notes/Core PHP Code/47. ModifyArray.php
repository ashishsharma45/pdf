<?php
	$name [0] = "Rahul";
	$name [1] = "Sonam";
	$name [2] = "Sumit";
	$name [3] = "Priti";
	echo $name[2] . "<br />";
	$name [2] = "PHP";
	echo $name[2];
?>