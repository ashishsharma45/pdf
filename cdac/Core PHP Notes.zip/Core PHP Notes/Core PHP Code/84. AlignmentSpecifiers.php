<?php
		print "<pre>";
		printf("%10s <br />","Shows");
		printf("%-10s <br />","Shows");
		print "</pre>";
?>