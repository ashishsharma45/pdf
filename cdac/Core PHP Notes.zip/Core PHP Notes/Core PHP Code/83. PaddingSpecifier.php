<?php
		printf("%08d <br />", 2345);
		printf("%08d <br />", 12345678);
		printf("% 8d <br />", 2345);
		printf("%'*8d <br />", 2345);
		printf("%'*-8d <br />", 2345);
?>