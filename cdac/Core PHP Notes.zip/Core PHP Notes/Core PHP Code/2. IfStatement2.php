<?php
	if (10>2):
		echo "Yes It is true <br />";
	endif;

	echo "Rest of the code";
?>