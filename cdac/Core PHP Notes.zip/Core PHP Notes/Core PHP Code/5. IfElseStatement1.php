<?php
	if (10<2)
	{
		echo "Condition is True <br />";
	}
	
	else
	{
		echo "Condition is False <br />";
	}
	
	echo "Rest of the code";
?>