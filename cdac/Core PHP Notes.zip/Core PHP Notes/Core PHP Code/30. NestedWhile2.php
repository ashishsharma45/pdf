<?php
	$num = 1;
	
	while ($num <= 2) :
		echo "GeekyShows Count: $num <br />";
		$num++;
		$val = 1;
		while ($val <= 3) :
			echo "Val: $val <br />";
			$val++;
		endwhile;
	endwhile;
?>