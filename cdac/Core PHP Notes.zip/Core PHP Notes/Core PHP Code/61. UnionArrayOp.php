<?php
	// PHP Union + Array operator
	 $a = array("Rahul"=>500, "Sonam"=>600, "Sumit"=>700);
	 $b = array("Rahul"=>"PHP", "Sonam"=>"Java", "Sam"=>"CSS", "JK"=>"Book");
	 $result = $b + $a;
	 print_r($result);

?>