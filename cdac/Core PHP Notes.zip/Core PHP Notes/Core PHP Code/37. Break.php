<?php
	for($num = 1; $num<= 5; $num++)
	{
		echo "GeekyShows Count: $num <br />";
		if ($num == 2)
			break;
	}
?>