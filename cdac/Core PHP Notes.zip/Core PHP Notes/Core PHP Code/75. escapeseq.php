<?php
	
	echo "Geekyshows <br />";
	echo "Geeky\nshows <br />";		
	echo "Geeky\tshows <br />";
	
		
?>