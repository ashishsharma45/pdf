<?php
	$result = (1 > 2) ? "Greater" : "Less" ;
	echo $result;
?>