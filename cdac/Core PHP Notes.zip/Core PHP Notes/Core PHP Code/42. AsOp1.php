<?php
	$name = array(1 => "Rahul", "Sonam", "Sumit", "Priti");
		// $name [1] = "Rahul";
		// $name [2] = "Sonam";
		// $name [3] = "Sumit";
		// $name [4] = "Priti";
	echo $name[4];
	
?>