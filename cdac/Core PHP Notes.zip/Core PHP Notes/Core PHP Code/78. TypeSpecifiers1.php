<?php
	$q = 2;
	$m = "Laptops";
	$p = 20000.50;
	
	printf("I have %d %s and the price is %f each", $q, $m, $p);
?>