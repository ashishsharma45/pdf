<?php
	$a = 3;
	$b = 3;
	echo "<br />" . $a;
	echo "<br />" . $a++ ;
	echo "<br />" . $a  ;
	echo "<br />" . $b ;
	echo "<br />" . ++$b ;
	echo "<br />" . $b ;
	
?>