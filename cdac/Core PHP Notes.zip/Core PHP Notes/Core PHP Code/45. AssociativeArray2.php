<?php
	$fees ["Rahul"] = 500;
	$fees ["Sonam"] = 300;
	$fees ["Sumit"] = 600;
	$fees ["Priti"] = 700;
	echo $fees["Sumit"];
?>