<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="">
    <title>GeekyShows</title>
</head>
<body>
    <h1>HTML, CSS and JavaScript inside PHP</h1>
    <?php
    // HTML Inside PHP
    $a = "Geekyshows";
    echo "<h2>Hello Geekyshows</h2>";
    // echo "<input type='text' value='Geekyshows'> <br />";  // Single Quote and Double Quote
    // echo "<input type='text' value=$a> <br />";            // with variable
    // echo "<h2 style='color: blue;'>Hello Geekyshows</h2> <br />"; // with css

    // // JavaScript inside PHP
    // echo "<script> alert('Geekyshows'); </script> ";

    ?>
</body>
</html>