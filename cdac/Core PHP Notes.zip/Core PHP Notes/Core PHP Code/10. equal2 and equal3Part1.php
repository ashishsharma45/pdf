<?php
	$num1 = 10;
	$num2 = 10;
	if($num1 == $num2)
		echo "Number is Equal";
	else
		echo "Number is not equal";
?>