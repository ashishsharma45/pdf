<?php
	if (!(5<2))
	{
		echo "Condition is True <br />";
	}
	else
	{
		echo "Condition is False <br />";
	}
	
?>