<?php
	echo "First Line <br />";
	display();
	echo "Second Line <br />";
	function display()
	{
		echo "Welcome to Geekyshows  <br />";
	}
	echo "Third Line  <br />";
	echo "Last Line  <br />";
?>