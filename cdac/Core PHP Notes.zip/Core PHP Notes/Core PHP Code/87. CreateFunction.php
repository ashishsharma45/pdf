<?php

	function display()
	{
		echo "Welcome to Geekyshows  <br />";
	}
	
	display();
?>