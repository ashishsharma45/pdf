<?php
	for($num = 1; $num<= 3; $num++)
	{
		echo "GeekyShows Count: $num <br />";
	}
?>