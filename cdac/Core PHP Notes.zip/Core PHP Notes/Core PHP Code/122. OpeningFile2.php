<?php
	// Opening a File
	$handle = fopen("geek.txt", "r") or die("File Not Found");

?>