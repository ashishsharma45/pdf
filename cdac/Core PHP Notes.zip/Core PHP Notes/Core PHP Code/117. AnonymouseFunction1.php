<?php
	// Normal Function 
	function show()
	{
		echo "Normal Function";
	}
	show(); // Calling Normal Function

	
	// Anonymous or Closures Functions
	$a = function ( )
		{
			echo "Anonymous Functions";
		};
	$a(); // Calling Anonymous Function
?>