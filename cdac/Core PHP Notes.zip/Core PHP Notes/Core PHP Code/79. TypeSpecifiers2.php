<?php
	$n = 456;
	printf("%%d <br />");
	printf("Decimal Integer %%d = %d <br />", $n);
	printf("Float or Double (Locale Aware) %%f = %f <br />", $n);
	printf("String %%s = %s <br />", $n);
	printf("Binary %%b = %b <br />", $n);
	printf("Scientific Notation %%e = %e <br />", $n);
	printf("Float or Double (Non-Locale Aware) %%F = %F <br />", $n);
	
?>