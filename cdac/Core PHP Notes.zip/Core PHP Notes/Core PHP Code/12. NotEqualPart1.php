<?php
	$num1 = 10;
	$num2 = "10";
	echo $num1 !== $num2;
?>