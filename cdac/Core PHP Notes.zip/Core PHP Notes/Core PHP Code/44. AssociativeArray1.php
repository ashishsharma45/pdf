<?php
	$fees ["Rahul"] = 500;
	echo $fees ["Rahul"];
	// echo "Rahul Fees: " . $fees ["Rahul"];
	//echo "Rahul Fees: {$fees ["Rahul"]}";
?>