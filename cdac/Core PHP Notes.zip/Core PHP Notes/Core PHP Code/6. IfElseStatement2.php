<?php
	if (10<2) :
		echo "Condition is True <br />";
	
	else :
		echo "Condition is False <br />";
	endif;
	
	echo "Rest of the code";
?>