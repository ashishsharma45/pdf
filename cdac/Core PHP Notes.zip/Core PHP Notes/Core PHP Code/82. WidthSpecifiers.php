<?php
		print "<pre>";
		printf("%8d <br />",2345);
		printf("%8d <br />",12345678);
		printf("%8d <br />",2345);
		printf("%-8d <br />",2345);
		print "</pre>";
		
		print "<pre>";
		printf("%10s <br />","Hi");
		printf("%10s <br />","Hello");
		printf("%10s <br />","GeekyShows");
		printf("%-10s <br />","Shows");
		print "</pre>";
?>