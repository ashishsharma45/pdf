<?php
	$num = 1;
	while ($num <= 5) :
		echo "GeekyShows Count: $num <br />";
		$num++;
	endwhile;
?>