<?php
		$arr = stat("geek.txt");
		echo $arr["size"];		// echo $arr[7]
?>