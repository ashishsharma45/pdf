<?php
	$name [ ] = 25;		//  $name [0] = 25;	
	echo $name[0];
	// echo "Value is $name[0]";
	// echo "Value is " . $name[0] ;	
?>