<?php
		$name = "GeekyShows";
		echo $name[4];
?>