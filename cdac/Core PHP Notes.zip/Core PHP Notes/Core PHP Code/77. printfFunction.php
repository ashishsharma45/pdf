<?php
	<?php
	$a = 2;
	$b = 20000;
	printf("I have %d laptops and price each %d",$a);
?>
?>