<?php
	$name = array(1=> "Rahul", 5 => "Sonam", 7=> "Sumit", 8=> "Priti");
		// $name [1] = "Rahul";
		// $name [5] = "Sonam";
		// $name [7] = "Sumit";
		// $name [8] = "Priti";
	echo $name[8];
	
?>