<?php
	function display($name1, $name2) // $name1 = "Welcome"
									// $name2 = "Geekyshows"
	{
		echo "$name1 to $name2 <br />";
	}
	display("Welcome", "Geekyshows");
	display("Not Welcome", "Google");
?>