<?php
	$num = 1;
	while (TRUE)
	{
		echo "GeekyShows Count: $num <br />";
		$num++;
		if($num == 5)
			break;
	}
?>