<?php

$result = sprintf("I have %d laptops and the price is %d each", 2, 20000);
 echo $result;
// sprintf("I have %d laptops and the price is %d each", 2, 20000);
// echo sprintf("I have %d laptops and the price is %d each", 2, 20000);

		
?>