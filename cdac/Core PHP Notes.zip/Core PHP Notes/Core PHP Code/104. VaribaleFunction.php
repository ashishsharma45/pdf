<?php 	
		function one()
		{
			echo "I am one <br />";
		}
		function two()
		{
			echo "I am Two <br />";
		}
		function three()
		{
			echo "I am Three <br />";
		}
		$f_variable = "two";	// assigning function name to a variable
		$f_variable();		// calling function, have to write $ sign
?>