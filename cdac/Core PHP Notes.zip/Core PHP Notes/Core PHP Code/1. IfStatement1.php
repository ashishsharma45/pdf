<?php
	if (10>2)
	{
		echo "Yes It is True <br />";
	}
	
	echo "Rest of the code";
?>