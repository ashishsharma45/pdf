<?php
	$date = 10;
	switch ($date)
	{
		case 10 :
			echo "C Programming" ;
			break;
			
		case 15 :
			echo "C++ Programming" ;
			break;
			
		case 20 :
			echo "PHP" ;
			break;
			
		case 25 :
			echo "Java <br />" ;
			echo "JavaScript <br />" ;
			break;
		
		case 30 :
			echo "Holiday" ;
			break;
		
		default :
			echo "No Exams" ;
	}
?>