<?php
	$name [ ] = "Rahul";		// $name [0] = "Rahul";
	$name [ ] = "Sonam";		// $name [1] = "Sonam";
	$name [ ] = "Sumit";		// $name [2] = "Sumit";
	$name [ ] = "Priti";		// $name [3] = "Priti";
	echo $name[2];		// cant echo $name [ ]; 
	
?>