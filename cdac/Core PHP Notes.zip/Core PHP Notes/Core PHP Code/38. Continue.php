<?php
	for($num = 1; $num<= 5; $num++)
	{
		if ($num == 2)
			continue;
		echo "GeekyShows Count: $num <br />";
	}
?>