<?php
	$fees = array("Rahul"=>500, "Sonam"=>300, "Sumit"=>600, "Priti"=>700);
	echo $fees["Priti"];
?>