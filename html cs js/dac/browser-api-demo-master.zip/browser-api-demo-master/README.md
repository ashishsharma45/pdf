# browser-api-demo
A simple demo to show usage of the Mozilla Browser API. See [https://developer.mozilla.org/en-US/docs/Web/API/Using_the_Browser_API](https://developer.mozilla.org/en-US/docs/Web/API/Using_the_Browser_API) for more details.
